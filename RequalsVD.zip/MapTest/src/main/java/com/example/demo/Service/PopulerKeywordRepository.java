package com.example.demo.Service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.vo.PopulerKeywordVO;

/**
 * PopulerKeywordRepository
 * @author _khn
 * @version 1.1v
 * @since 2019.07
 * kakaoBank test 과제의 
 * 인기검색어 관련 JpaRepository interface
 */

@Repository
public interface PopulerKeywordRepository extends JpaRepository<PopulerKeywordVO, String>{

	@Query(value="SELECT * FROM (SELECT * FROM populerkeyword pk ORDER BY pk.cnt DESC) WHERE ROWNUM <= 10", nativeQuery = true)
	List<PopulerKeywordVO> populerKeywordFindAll();

}
