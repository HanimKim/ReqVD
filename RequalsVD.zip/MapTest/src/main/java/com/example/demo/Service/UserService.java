package com.example.demo.Service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.example.demo.vo.UserVO;

/**
 * UserService
 * @author _khn
 * @version 1.1v
 * @since 2019.07
 * kakaoBank test 과제의 
 * 사용자 로그인 관련 service
 */

@Service
public class UserService {
	private UserRepository userRepository;
	
	public UserService(UserRepository userRepository) {
		this.userRepository = userRepository;
	}
	
	@Transactional
	public UserVO userSaveAndUpdate(UserVO vo) {
		return userRepository.save(vo);
	}
	@Transactional
	public Optional<UserVO> userFindById(UserVO vo) {
		return userRepository.findById(vo.getId());
	}
	@Transactional
	public Optional<UserVO> userFindByIdAndPw(UserVO vo) {
		return userRepository.findByIdAndPw(vo.getId(),vo.getPw());
	}
}
