package com.example.demo.Controller;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.Service.PopulerKeywordService;
import com.example.demo.Service.UserService;
import com.example.demo.vo.PopulerKeywordVO;
import com.example.demo.vo.UserVO;

/**
 * MainController
 * @author _khn
 * @version 1.1v
 * @since 2019.07
 * kakaoBank test 과제의 Controller
 *
 */

@Controller
public class MainController {
	@Autowired
	private UserService userService;
	
	@Autowired
	private PopulerKeywordService populerKeywordService; 
	
	//로그인화면 진입 전 이전 사용자 데이터 생성
	@RequestMapping(value="/kakaoBank")
	public String main(){
		System.out.println("##################### main Function START ###################" );
		UserVO vo = new UserVO();
		try {
			vo.setId("test");
			vo.setPw(sha256("1234").toString());
			
			Optional<UserVO> configVO = userService.userFindById(vo);
			if(!configVO.isPresent()) { 
				userService.userSaveAndUpdate(vo);
			}
		}catch(Exception e) {
			System.out.println("##################### main() another Exception ###################" );
			System.out.println("Exception Message : " + e.getMessage());
		}
		System.out.println("##################### main Function END ###################" );
		
		return "main";
	}
	
	//비밀번호 암호화(단방향)
	private String sha256(String msg){
		System.out.println("##################### sha256 Function START ###################" );
		
		StringBuffer hexString = new StringBuffer();
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] hash = digest.digest(msg.getBytes("UTF-8"));
			
			for (int i = 0; i < hash.length; i++) {
				String hex = Integer.toHexString(0xff & hash[i]);
				if(hex.length() == 1) hexString.append('0');
				hexString.append(hex);
			}
		}catch(NoSuchAlgorithmException e){
			System.out.println("##################### sha256() NoSuchAlgorithmException ###################" );
			System.out.println("Exception Message : " + e.getMessage());
		}catch(UnsupportedEncodingException e) {
			System.out.println("##################### sha256() UnsupportedEncodingException ###################" );
			System.out.println("Exception Message : " + e.getMessage());;
		}catch(Exception e) {
			System.out.println("##################### sha256() another Exception ###################" );
			System.out.println("Exception Message : " + e.getMessage());
		}
		System.out.println("##################### sha256 Function END ###################" );
		
		return hexString.toString();
	}
	
	//로그인
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public @ResponseBody Map<String, String> login(UserVO userVO){
		System.out.println("##################### login Function START ###################" );
		Map<String, String> res = new HashMap<String, String>();
		
		try {
			Optional<UserVO> configVO = userService.userFindByIdAndPw(userVO);
			if(configVO.isPresent()) {
				res.put("userId", userVO.getId());
				res.put("code", "0000");
				res.put("msg", "로그인에 성공하였습니다.");
			}else {
				res.put("code", "1001");
				res.put("msg", "로그인에 실패하였습니다. 아이디, 패스워드를 확인하세요.");
			}
		}catch(Exception e) {
			System.out.println("##################### login() another Exception ###################" );
			System.out.println("Exception Message : " + e.getMessage());
			res.put("code", "1002");
			res.put("msg", e.getMessage());
		}

		
		
		System.out.println("##################### login Function END ###################" );
		return res;
	}

	//인기검색어 갱신
	@RequestMapping(value="/populerKeyword",method=RequestMethod.POST)
	public @ResponseBody Map<String, Object> populerKeyword(PopulerKeywordVO populerKeywordVO){
		System.out.println("##################### populerKeyword Function START ###################" );
		Map<String, Object> res = new HashMap<String, Object>();
		List<PopulerKeywordVO> populerKeywordList = null;
		try {
			populerKeywordService.populerKeywordRenewal(populerKeywordVO);
			populerKeywordList = populerKeywordService.populerKeywordFindAll();
			res.put("code", "0000");
			res.put("msg", "success!!");
		}catch(Exception e){
			System.out.println("##################### populerKeyword() another Exception ###################" );
			System.out.println("Exception Message : " + e.getMessage());
			res.put("code", "2001");
			res.put("msg", e.getMessage());
		}
		res.put("populerKeywordList", populerKeywordList);
		
		System.out.println("##################### populerKeyword Function END ###################" );
		
		return res;
	}
	
	//인기검색어 목록 초기세팅
	@RequestMapping(value="/startPopKeyword",method=RequestMethod.POST)
	public @ResponseBody Map<String, Object> startPopKeyword(){
		System.out.println("##################### startPopKeyword Function START ###################" );
		Map<String, Object> res = new HashMap<String, Object>();
		List<PopulerKeywordVO> populerKeywordList = null;
		try {
			populerKeywordList = populerKeywordService.populerKeywordFindAll();
			res.put("code", "0000");
			res.put("msg", "success!!");
		}catch(Exception e){
			System.out.println("##################### startPopKeyword() another Exception ###################" );
			System.out.println("Exception Message : " + e.getMessage());
			res.put("code", "2005");
			res.put("msg", e.getMessage());
		}
		res.put("populerKeywordList", populerKeywordList);
		
		System.out.println("##################### startPopKeyword Function END ###################" );
		
		return res;
	}
}	
