package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.example.demo.vo.PopulerKeywordVO;

/**
 * PopulerKeywordService
 * @author _khn
 * @version 1.1v
 * @since 2019.07
 * kakaoBank test 과제의 
 * 인기검색어 관련 service
 */

@Service
public class PopulerKeywordService {
	private PopulerKeywordRepository populerKeywordRepository;
	
	public PopulerKeywordService(PopulerKeywordRepository populerKeywordRepository) {
		this.populerKeywordRepository = populerKeywordRepository;
	}
	
	@Transactional
	public PopulerKeywordVO populerKeywordRenewal(PopulerKeywordVO vo) {
		Optional<PopulerKeywordVO> configVO = populerKeywordRepository.findById(vo.getKeyword());
		if(configVO.isPresent()) {
			PopulerKeywordVO tempVO = configVO.get();
			int cnt = tempVO.getCnt() + 1;
			vo.setCnt(cnt);
			return populerKeywordRepository.save(vo);
		}else {
			vo.setCnt(1);
			return populerKeywordRepository.save(vo);
		}
	}

	@Transactional
	public List<PopulerKeywordVO> populerKeywordFindAll() {
		return populerKeywordRepository.populerKeywordFindAll();
	}
}
