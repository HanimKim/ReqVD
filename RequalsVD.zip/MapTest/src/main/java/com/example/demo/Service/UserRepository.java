package com.example.demo.Service;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.vo.UserVO;

/**
 * UserRepository
 * @author _khn
 * @version 1.1v
 * @since 2019.07
 * kakaoBank test 과제의 
 * 사용자 로그인 관련 JpaRepository interface
 */

@Repository
public interface UserRepository extends JpaRepository<UserVO, String>{
	@Query(value="SELECT * FROM USER U WHERE U.ID = :id AND U.PW = :password",nativeQuery = true)
	Optional<UserVO> findByIdAndPw(@Param("id")String id,@Param("password")String pw);
}
