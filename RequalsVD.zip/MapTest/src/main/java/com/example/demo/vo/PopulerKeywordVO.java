package com.example.demo.vo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * PopulerKeywordVO
 * @author _khn
 * @version 1.1v
 * @since 2019.07
 * kakaoBank test 과제의 
 * 인기검색어 관련 테이블의 VO
 * (VO에 작성된 테이블명과 컬럼명으로 서버 시작시 자동으로 DB가 생성된다.)
 */

@Entity
@Table(name="populerkeyword")
public class PopulerKeywordVO {
	@Id
	@Column(name="keyword")
	private String keyword;
	
	@Column(name="cnt")
	private int cnt;

	
	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public int getCnt() {
		return cnt;
	}

	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	
	
}
