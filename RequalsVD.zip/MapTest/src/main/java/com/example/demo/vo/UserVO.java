package com.example.demo.vo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * UserVO
 * @author _khn
 * @version 1.1v
 * @since 2019.07
 * kakaoBank test 과제의 
 * 사용자 로그인 관련하여 ID, password 관련 테이블의 VO
 * (VO에 작성된 테이블명과 컬럼명으로 서버 시작시 자동으로 DB가 생성된다.)
 */

@Entity
@Table(name="user")
public class UserVO {
	@Id		//key값
	@Column(name="ID")
	private String id;
	@Column(name="PW")
	private String pw;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
}
